<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<script src="<?= public_path('admin/vendor/jquery/jquery.min.js') ?>"></script>
<script src="<?= public_path('admin/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
<script src="<?= public_path('admin/vendor/jquery-easing/jquery.easing.min.js') ?>"></script>
<script src="<?= public_path('admin/js/sb-admin-2.min.js') ?>"></script>
<script src="<?= public_path('admin/vendor/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?= public_path('admin/vendor/datatables/dataTables.bootstrap4.min.js') ?>"></script>
<script src="<?= public_path('admin/js/notify.js') ?>"></script>
<script src="<?= public_path('admin/js/validation/register.js') ?>"></script>
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable();
        });
    </script>
</body>

</html>