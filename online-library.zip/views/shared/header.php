<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow">
    <h3 class="my-0 mr-md-auto font-weight-normal">OOP (PHP) STARTER KIT</h3>
    <nav class="my-2 my-md-0 mr-md-3">
        <a class="p-2 text-dark" href="<?= URI('/') ?>">Home</a>
        <a class="p-2 text-dark" href="<?= URI('/register') ?>">Register</a>
        <a class="p-2 text-dark" href="<?= URI('/login') ?>">Login</a>
    </nav>
</div>